//
//  ViewController.swift
//  xmlparsing
//
//  Created by MACOS on 11/23/16.
//  Copyright © 2016 surat. All rights reserved.
//

import UIKit

class ViewController: UIViewController,XMLParserDelegate,UITableViewDelegate,UITableViewDataSource {

     var strcntent = "";
    
    var arr = Array<Array<String>>()
   
    var brr  = Array<String>()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
         let urone = URL(string: "http://www.divyabhaskar.co.in/rss-feed/2425/")
        
        do{
            let dt = try Data(contentsOf: urone!)
            
            let xml = XMLParser(data: dt);
            xml.delegate = self;
            
            xml.parse();
            
            
            
            
        }
        catch
        {
            
            
        }
      
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        
        return arr.count;
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return  3;
    }
    func parserDidStartDocument(_ parser: XMLParser) {
        
        arr.removeAll();
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath);
        
        var temp = Array<String>();
        temp  = arr[indexPath.section]
        
        cell.textLabel?.text =  temp[indexPath.row];
        
        return cell;
        
    }
    func parserDidEndDocument(_ parser: XMLParser) {
        
        
        print(arr);
        
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        
        
        if elementName == "NewsHeadline" {
            
            
            brr.removeAll();
            
            
            
        }
        
        
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        
        
        if elementName == "title" || elementName == "shortDescription"||elementName == "description"
        {
            
            brr.append(strcntent);
            
            
        }
        else if elementName == "NewsHeadline"
        {
            
            arr.append(brr);
            
            brr.removeAll();
            
            
            
            
        }
        
        
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        
        strcntent = string;
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

